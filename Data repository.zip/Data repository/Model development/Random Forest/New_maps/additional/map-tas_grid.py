import geopandas as gpd
import matplotlib.pyplot as plt
import pandas as pd

# Load the shapefile
shapefile_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\Creating Tas plain shapefile\Tasmania_plain.shp'
tasmania = gpd.read_file(shapefile_path)

# Load the CSV file with latitude and longitude coordinates
data_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\1_Grid_Tas.CSV'
df = pd.read_csv(data_path)

# Convert latitude and longitude to Points geometry
geometry = gpd.points_from_xy(df['Lon'], df['Lat'])

# Create a GeoDataFrame from the DataFrame and geometry
gdf = gpd.GeoDataFrame(df, geometry=geometry)

# Plot the shapefile and data points
fig, ax = plt.subplots(figsize=(10, 10))
tasmania.plot(ax=ax, color='lightblue')
gdf.plot(ax=ax, color='red', markersize=1)
plt.title('FFDI Points on Tasmania Map')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()

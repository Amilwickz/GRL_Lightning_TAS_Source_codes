import csv

# Path to the input CSV file
input_csv_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\2_Grided_FFDI.csv'

# Path to store the new CSV file with selected columns
output_csv_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\dry_days_cells.csv'

# Columns to extract from the input CSV file
columns_to_extract = ['YYYYMMDD', 'Lat', 'Lon']

# Read the input CSV file and extract selected columns
with open(input_csv_file_path, 'r') as input_csv_file, open(output_csv_file_path, 'w', newline='') as output_csv_file:
    csv_reader = csv.DictReader(input_csv_file)
    csv_writer = csv.DictWriter(output_csv_file, fieldnames=columns_to_extract)
    csv_writer.writeheader()

    for row in csv_reader:
        selected_row = {key: row[key] for key in columns_to_extract}
        csv_writer.writerow(selected_row)

print(f"Selected columns extracted and written to '{output_csv_file_path}'.")


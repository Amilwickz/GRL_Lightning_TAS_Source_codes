import pandas as pd

# Read the CSV files
solar_rad_file = r'E:\Ignition Modelling project\Data\Solar radiation\single file\1_All_solarRad_single_file.csv'
dry_days_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\1_Dry_days_random.CSV'

solar_rad_df = pd.read_csv(solar_rad_file)
dry_days_df = pd.read_csv(dry_days_file)

# Merge the data based on YYYYMMDD column
merged_df = pd.merge(solar_rad_df, dry_days_df[['YYYYMMDD']], on='YYYYMMDD')

# Save the merged data to a new CSV file
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\5_Solar_on_dry_days.csv'
merged_df.to_csv(output_file, index=False)


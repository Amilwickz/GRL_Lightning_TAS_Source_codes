import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Rectangle

# Load your data
data = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\Z_summing_data\Z_summing_data_including_Type_fuel-4-category_TPI\4_Binary_classification_dry_lightning_Aug_2004_to_Dec_2018.CSV')

# Select key variables for summary statistics
selected_columns = ['Aspect', 'Elevation', 'Slope', 'TPI', 'fuel load', 'FMI', 'SDI', 'FFDI', 'RH', 'solar_rad', 'max_temp', 'vp_deficit', 'wind_speed', 'wind_direction']

# Filter data based on 'Binary' column
binary_one_data = data[data['Binary'] == 1]
binary_zero_data = data[data['Binary'] == 0]

# Create figure and axes for subplots
fig, axs = plt.subplots(7, 4, figsize=(10, 12))

# Plot histograms and kernel density plots for each variable with mean and std values for all data
for i, column in enumerate(selected_columns, 1):
    if i <= 28:
        # Plot for ['Binary'] == 0
        plt.subplot(7, 4, 2 * i - 1)
        sns.histplot(binary_zero_data[column], bins=20, color='green', edgecolor='black', kde=True)
        plt.xlabel(column, fontsize=8, weight='bold')  # X-axis title
        plt.ylabel('', fontsize=10)  # Y-axis title
        mean_val = binary_zero_data[column].mean()
        std_val = binary_zero_data[column].std()
        plt.text(0.5, 1.1, f'Mean: {mean_val:.1f}, Std: {std_val:.1f}', transform=plt.gca().transAxes, fontsize=8,
                ha='center', va='center', bbox=dict(facecolor='white', alpha=0.0, edgecolor='none'))

        # Plot for ['Binary'] == 1
        plt.subplot(7, 4, 2 * i)
        sns.histplot(binary_one_data[column], bins=20, color='navy', edgecolor='black', kde=True)
        plt.xlabel(column, fontsize=8, weight='bold')  # X-axis title
        plt.ylabel('', fontsize=8)  # Y-axis title
        mean_val = binary_one_data[column].mean()
        std_val = binary_one_data[column].std()
        plt.text(0.5, 1.1, f'Mean: {mean_val:.1f}, Std: {std_val:.1f}', transform=plt.gca().transAxes, fontsize=8,
                ha='center', va='center', bbox=dict(facecolor='white', alpha=0.0, edgecolor='none'))
    else:
        plt.subplot(7, 4, i)
        plt.axis('off')  # Turn off the axis for subplot 27 and 28
        plt.tick_params(axis='both', which='both', bottom=False, top=False, left=False, right=False, labelbottom=False, labelleft=False)

# Add legend with custom markers and adjustable location
legend_handles = [Rectangle((0, 0), 1, 1, color='green', label='Lightning strikes and no fire ignition'),
                  Rectangle((0, 0), 1, 1, color='navy', label='Lightning strikes and fire ignition')]
legend_loc = (0.4, -1.5)  # Change these coordinates as needed
plt.legend(handles=legend_handles, loc='lower right', bbox_to_anchor=legend_loc, fancybox=False, shadow=False, ncol=2)
plt.subplots_adjust(left=0.15, bottom=0.095, right=0.909, top=0.954, wspace=0.77, hspace=0.99)

# Add a common y-axis title
plt.text(0.05, 0.5, 'Frequency', transform=plt.gcf().transFigure, fontsize=12, rotation='vertical', va='center')

# Remove grids
sns.despine(left=True, bottom=True)

# Save figure
plt.savefig('7B_Random Forest-Resampling-summary statistics of key variables_V2.png')
plt.savefig('7B_Random Forest-Resampling-summary statistics of key variables_V2.tif')
plt.savefig('7B_Random Forest-Resampling-summary statistics of key variables_V2.tif')
plt.show()


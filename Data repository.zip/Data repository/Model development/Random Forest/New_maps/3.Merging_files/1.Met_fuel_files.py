import pandas as pd

# Define file paths
ffd_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\2_Grided_FFDI.CSV'
solar_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\3_Grided_Solar.CSV'
fuel_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\12_Grided_Fuel_merged.CSV'
wind_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\4_Grided_Wind.CSV'
FMI_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\1.Dry_days_95th_on_lightning_duration\2_FMIs_on_dry_days.CSV'
SDI_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\1.Dry_days_95th_on_lightning_duration\3_SDIs_on_dry_days.CSV'



output_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\3.Merging_files\1_Met_fuel_files.CSV'

# Read CSV files into pandas DataFrames
ffd_df = pd.read_csv(ffd_path)
solar_df = pd.read_csv(solar_path)
fuel_df = pd.read_csv(fuel_path)
wind_df = pd.read_csv(wind_path)
FMI_df = pd.read_csv(FMI_path)
SDI_df = pd.read_csv(SDI_path)

# Merge based on matching 'YYYYMMDD', 'Lat', 'Lon' columns
merged_df = pd.merge(ffd_df, solar_df, on=['YYYYMMDD', 'Lat', 'Lon'], how='inner')
merged_df = pd.merge(merged_df, fuel_df, on=['YYYYMMDD', 'Lat', 'Lon'], how='inner')
merged_df = pd.merge(merged_df, wind_df, on=['YYYYMMDD', 'Lat', 'Lon'], how='inner')
merged_df = pd.merge(merged_df, FMI_df, on=['YYYYMMDD', 'Lat', 'Lon'], how='inner')
merged_df = pd.merge(merged_df, SDI_df, on=['YYYYMMDD', 'Lat', 'Lon'], how='inner')

# Select only the desired columns
merged_df = merged_df[['YYYYMMDD', 'Lat', 'Lon','FMI','SDI', 'FFDI', 'radiation', 'Fuel_Load', 'Wind_speed','Wind_direction']]

# Write merged data to new CSV file
merged_df.to_csv(output_path, index=False)

# Print number of matching records
print(f'Number of matching records: {len(merged_df)}')

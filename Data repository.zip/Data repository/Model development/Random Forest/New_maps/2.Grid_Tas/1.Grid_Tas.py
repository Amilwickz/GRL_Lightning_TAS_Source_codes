import csv

# Define the limits and resolution
lat_start = -44.0
lat_end = -39.0
lon_start = 143.0
lon_end = 149.0
resolution = 0.05

# Calculate the number of cells
num_lat_cells = int((lat_end - lat_start) / resolution)
num_lon_cells = int((lon_end - lon_start) / resolution)
total_cells = num_lat_cells * num_lon_cells

# Open CSV file for writing
file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\1_Grid_Tas.csv'
with open(file_path, 'w', newline='') as csvfile:
    fieldnames = ['Lat', 'Lon']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()

    # Loop through cells and write center coordinates to CSV
    for lat_cell in range(num_lat_cells):
        lat_center = lat_end - (lat_cell + 0.5) * resolution

        for lon_cell in range(num_lon_cells):
            lon_center = lon_start + (lon_cell + 0.5) * resolution
            writer.writerow({'Lat': lat_center, 'Lon': lon_center})

print(f"CSV file '{file_path}' created successfully with {total_cells} cells.")


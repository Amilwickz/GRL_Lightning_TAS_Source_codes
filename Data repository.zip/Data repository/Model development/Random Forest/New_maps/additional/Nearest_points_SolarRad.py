import pandas as pd
from sklearn.neighbors import KDTree
from geopy.distance import great_circle

# Load the CSV files
set_a_df = pd.read_csv(
    r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\1_Grid_Tas.CSV')
set_b_df = pd.read_csv(
    r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\5_Solar_on_dry_days-unique.CSV')

# Initialize KDTree with SET B coordinates
tree = KDTree(set_b_df[['lat', 'lon']])

# Empty lists to store results
nearest_points = []

# Iterate through each point in SET A
for idx, row in set_a_df.iterrows():
    # Find the nearest neighbor index and distance
    dist, nn_idx = tree.query([[row['Lat'], row['Lon']]], k=1)

    # Get the corresponding lat and lon values from SET B
    nearest_point = set_b_df.iloc[nn_idx[0][0]]

    # Calculate distance using great circle distance
    distance = great_circle((row['Lat'], row['Lon']), (nearest_point['lat'], nearest_point['lon'])).kilometers

    # Append the results to the list
    nearest_points.append([nearest_point['lat'], nearest_point['lon'], row['Lat'], row['Lon'], distance])

# Create DataFrame for nearest points
nearest_points_df = pd.DataFrame(nearest_points, columns=['lat', 'lon', 'Lat', 'Lon', 'Distance'])

# Save nearest points to CSV
output_csv_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\Nearest_points_SolarRad.CSV'
nearest_points_df.to_csv(output_csv_path, index=False)

print(f"Nearest points CSV file saved at {output_csv_path}")

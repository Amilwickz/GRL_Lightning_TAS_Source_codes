import geopandas as gpd
import pandas as pd


# Paths to CSV file and shapefile
elevation_points_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\Elevation data-lightning\1_Elevation_points_TIF_file.csv'
tasmania_shapefile = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\Creating Tas plain shapefile\Tasmania_plain.shp'


# Read CSV file containing elevation points
elevation_points_df = pd.read_csv(elevation_points_file)


# Load Tasmania shapefile
tasmania_boundary = gpd.read_file(tasmania_shapefile)


# Convert latitude and longitude columns to a GeoDataFrame
elevation_points_gdf = gpd.GeoDataFrame(elevation_points_df, geometry=gpd.points_from_xy(elevation_points_df['Lon'], elevation_points_df['Lat']), crs='EPSG:4326')


# Perform spatial join to find points inside the Tasmania boundary
elevation_points_inside_tasmania = gpd.sjoin(elevation_points_gdf, tasmania_boundary, op='within')


# Filter elevation points with Elevation >= 0
elevation_points_filtered = elevation_points_inside_tasmania[elevation_points_inside_tasmania['Elevation'] >= 0]


# Drop unnecessary columns from the result
elevation_points_filtered = elevation_points_filtered[['Lat', 'Lon', 'Elevation']]


# Path to output CSV file
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\1.Dry_days_95th_on_lightning_duration\7_Elevation_Tas.csv'


# Save filtered data to the output CSV file
elevation_points_filtered.to_csv(output_file, index=False)


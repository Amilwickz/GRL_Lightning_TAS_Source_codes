import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.geometry import Polygon
from scipy.interpolate import griddata
from scipy.ndimage import gaussian_filter
import numpy as np


# Read the CSV file
csv_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\5.Predicted_probability_maps\3_Probability_mean.csv'
df = pd.read_csv(csv_file)

# Read the Tasmania shapefile
shapefile_tasmania = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\Creating Tas plain shapefile\Tasmania_plain.shp'
gdf_tasmania = gpd.read_file(shapefile_tasmania)
gdf_tasmania = gdf_tasmania.to_crs('EPSG:4326')

# Read the TWWHA Graphics shapefile
shapefile_twwha = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\TWWHA_Graphics\TWWHA_Graphics.shp'
gdf_twwha = gpd.read_file(shapefile_twwha)
gdf_twwha = gdf_twwha.to_crs('EPSG:4326')

# Define the extent of the grid
minimum_latitude = -44.0
maximum_latitude = -39.0
minimum_longitude = 143.0
maximum_longitude = 149.0

# Create a new GeoDataFrame for the grid cells
geometry = [Polygon([(row['Lower_Longitude'], row['Lower_Latitude']),
                    (row['Higher_Longitude'], row['Lower_Latitude']),
                    (row['Higher_Longitude'], row['Higher_Latitude']),
                    (row['Lower_Longitude'], row['Higher_Latitude'])])
           for idx, row in df.iterrows()]
grid_gdf = gpd.GeoDataFrame(df, geometry=geometry, crs='EPSG:4326')

# Merge grid data with Tasmania shapefile to get common geometries
merged_gdf = gpd.sjoin(grid_gdf, gdf_tasmania, how='inner', op='intersects')

# Create a regular grid to interpolate values
xi, yi = np.meshgrid(np.linspace(minimum_longitude, maximum_longitude, 500),
                     np.linspace(minimum_latitude, maximum_latitude, 500))

# Interpolate the log of the mean predicted probabilities
zi = griddata((merged_gdf['Lower_Longitude'], merged_gdf['Lower_Latitude']),
              np.log(merged_gdf['Mean Predicted Probability']),
              (xi, yi), method='cubic')

# Apply Gaussian smoothing to the interpolated data
zi_smooth = gaussian_filter(zi, sigma=0.1)  # Adjust sigma for the desired level of smoothing

# Create a mask using the Tasmania shapefile boundary
tasmania_mask = gdf_tasmania.geometry.unary_union

# Set values outside the Tasmania mask to np.nan
zi_smooth[~np.array([point.within(tasmania_mask) for point in gpd.points_from_xy(xi.flatten(), yi.flatten())]).reshape(xi.shape)] = np.nan

# Plot the smoothed map with values outside the Tasmania mask in white
fig, ax = plt.subplots(figsize=(6, 6))
c = ax.contourf(xi, yi, zi_smooth, cmap='viridis', extend='both', levels=4000)  # Use a large number of levels for smooth gradient
gdf_tasmania.boundary.plot(ax=ax, linewidth=0.5, color='Black')  # Plot the Tasmania boundary in white
gdf_tasmania.plot(ax=ax, facecolor='none')  # Plot the Tasmania shapefile

# Plot the TWWHA Graphics boundary in white
gdf_twwha.boundary.plot(ax=ax, linewidth=0.5, color='black')

# Add the text 'Ben Lomond National Park' at the specified coordinates
ax.text(147.666, -41.550, 'Ben Lomond\n National Park', fontsize=5, color='white', ha='center', va='center', weight='bold')

# Add the text 'Savage River National Park' at the specified coordinates
ax.text(145.405, -41.352, 'Savage River\n National Park', fontsize=5, color='white', ha='center', va='center', weight='bold')

# Add the text 'Lake Gordon' at the specified coordinates
ax.text(146.000, -42.500, 'Lake Gordon', fontsize=5, color='white', ha='center', va='center', weight='bold')

# Add the text 'twwha' at the specified coordinates
#ax.text(146.000, -42.500, 'TWWHA', fontsize=5, color='white', ha='center', va='center', weight='bold')

# Add a continuous vertical colorbar with only 'Low' and 'High' labels
cbar = plt.colorbar(c, ax=ax, orientation='vertical')
cbar.set_ticks([])  # Remove all ticks

# Add the text 'cake' outside the plot area
fig.text(0.855, 0.85, 'High', fontsize=8, color='black', ha='center', va='center')
fig.text(0.875, 0.50, 'Medium', fontsize=8, color='black', ha='center', va='center')
fig.text(0.855, 0.15, 'Low', fontsize=8, color='black', ha='center', va='center')

# Save the plot as .eps vector graphics format
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.xlim(minimum_longitude, maximum_longitude)
plt.ylim(minimum_latitude, maximum_latitude)
plt.savefig(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\5.Predicted_probability_maps\6_Predicted-smooth_TWWHA.eps', format='eps')
plt.savefig(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\5.Predicted_probability_maps\6_Predicted-smooth_TWWHA.tif', format='tif')

plt.show()


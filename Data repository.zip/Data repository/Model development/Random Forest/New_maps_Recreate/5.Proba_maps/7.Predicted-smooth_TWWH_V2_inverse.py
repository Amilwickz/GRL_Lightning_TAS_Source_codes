import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from shapely.geometry import Polygon
from matplotlib.colors import Normalize
from matplotlib import cm
import numpy as np  # Import numpy for log transformation
plt.style.use("ggplot")


# Read the CSV file with grid cell coordinates and 'Bayes Predicted Probability'
csv_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\5.Proba_maps\4_Probability_mean_adjust.csv'
df = pd.read_csv(csv_file)


# Apply log transformation to 'Bayes Predicted Probability'
df['Log_Bayes_Predicted_Probability'] = np.log(df['Bayes Predicted Probability'])


# Create GeoDataFrame from the CSV data
geometry = [Polygon([(row['Lower_Longitude'], row['Lower_Latitude']),
                   (row['Higher_Longitude'], row['Lower_Latitude']),
                   (row['Higher_Longitude'], row['Higher_Latitude']),
                   (row['Lower_Longitude'], row['Higher_Latitude'])])
          for idx, row in df.iterrows()]
gdf_grid_cells = gpd.GeoDataFrame(df, geometry=geometry, crs='EPSG:4326')


# Read the Tasmania shapefile
shapefile_tasmania = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\Creating Tas plain shapefile\Tasmania_plain.shp'
gdf_tasmania = gpd.read_file(shapefile_tasmania)
gdf_tasmania = gdf_tasmania.to_crs('EPSG:4326')


# Read the TWWHA Graphics shapefile
shapefile_twwha = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\TWWHA_Graphics\TWWHA_Graphics.shp'
gdf_twwha = gpd.read_file(shapefile_twwha)
gdf_twwha = gdf_twwha.to_crs('EPSG:4326')


# Normalize log-transformed 'Bayes Predicted Probability' for colormap
norm = Normalize(vmin=df['Log_Bayes_Predicted_Probability'].min(), vmax=df['Log_Bayes_Predicted_Probability'].max())
cmap = cm.get_cmap('RdPu_r')  # RdPu reversed colormap for color intensity


# Plotting
fig, ax = plt.subplots(figsize=(10, 8))
gdf_tasmania.boundary.plot(ax=ax, linewidth=0.5, color='black')  # Plot Tasmania boundary
gdf_tasmania.plot(ax=ax, facecolor='none')  # Plot Tasmania shapefile


# Plot grid cells with color intensity based on log-transformed 'Bayes Predicted Probability'
for idx, row in gdf_grid_cells.iterrows():
   color = cmap(norm(row['Log_Bayes_Predicted_Probability']))
   gpd.GeoSeries(row['geometry']).plot(ax=ax, color=color, edgecolor='none')


# Customize plot appearance
ax.set_xlabel('Longitude', fontsize=16, color='black', ha='center', va='center', labelpad=20)
ax.set_ylabel('Latitude', fontsize=16, color='black', ha='center', va='center', labelpad=20)


# Add colorbar
sm = plt.cm.ScalarMappable(cmap='RdPu_r', norm=norm)
sm.set_array([])
cbar = plt.colorbar(sm)
cbar_label = 'Log(Predicted Probability)'
cbar.set_label(cbar_label, fontsize=16, color='black', ha='center', va='center', labelpad=20)  # Adjust labelpad here


# Plot the TWWHA Graphics boundary in white
gdf_twwha.boundary.plot(ax=ax, linewidth=0.5, color='black')


# Add the text 'Ben Lomond National Park' at the specified coordinates
ax.text(147.666, -41.75, 'Ben Lomond\nplateau', fontsize=10, color='black', ha='center', va='center')


# Add the text 'Savage River National Park' at the specified coordinates
ax.text(145.405, -41.5, 'Tarkine', fontsize=10, color='black', ha='center', va='center' )


# Add the text 'Lake Gordon' at the specified coordinates
ax.text(146.000, -42.500, 'Lake Gordon', fontsize=10, color='black', ha='center', va='center')


# Set CRS to EPSG:4326
ax.set_xlim(gdf_tasmania.total_bounds[0], gdf_tasmania.total_bounds[2])
ax.set_ylim(gdf_tasmania.total_bounds[1], gdf_tasmania.total_bounds[3])


# Modify tick numbers color to black
ax.tick_params(axis='both', colors='black')


# Change plot grid face color to white
ax.set_facecolor('white')


# Include a small triangle marker with outline at specified positions
ax.plot(147.666, -41.550, marker='^', markersize=10, color='yellow', markeredgewidth=1, markeredgecolor='black', fillstyle='full')
ax.plot(145.405, -41.352, marker='^', markersize=10, color='yellow', markeredgewidth=1, markeredgecolor='black', fillstyle='full')


plt.savefig(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\5.Proba_maps\7_Predicted-smooth_TWWHA_V2_adj_inv.eps', format='eps')
plt.savefig(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\5.Proba_maps\7_Predicted-smooth_TWWHA_V2_adj_inv.tif', format='tif')
plt.savefig(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\5.Proba_maps\7_Predicted-smooth_TWWHA_V2_adj_inv.png', format='png')


# Show plot
plt.show()


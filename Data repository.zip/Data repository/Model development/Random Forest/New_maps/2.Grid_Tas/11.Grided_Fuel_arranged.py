import pandas as pd

# Load the CSV files into pandas dataframes
dry_days_cells = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\dry_days_cells.CSV')
grided_fuel = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\10_Grided_Fuel_V2.CSV')

# Extract the year from 'YYYYMMDD' in dry_days_cells and calculate previous year
dry_days_cells['Prev_Year'] = dry_days_cells['YYYYMMDD'].astype(str).str[:4].astype(int) - 1

# Merge dry_days_cells with grided_fuel on Lat and Lon columns
merged_df = pd.merge(dry_days_cells, grided_fuel, on=['Lat', 'Lon'])

# Filter rows where 'Year' matches 'Prev_Year'
filtered_df = merged_df[merged_df['Year'] == merged_df['Prev_Year']]

# Create the final dataframe with required columns
final_df = filtered_df[['YYYYMMDD', 'Lat', 'Lon', 'Fuel_Load']]

# Save the final dataframe to CSV
final_df.to_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\11_Grided_Fuel_arranged.CSV', index=False)


import pandas as pd

# File path
input_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\9_Grided_Fuel.CSV'

# Read the CSV file into a DataFrame
df = pd.read_csv(input_file)

# Find the number of unique locations (unique combinations of latitude and longitude)
unique_locations = df[['Lat', 'Lon']].drop_duplicates().shape[0]

print(f'The number of unique locations is: {unique_locations}')

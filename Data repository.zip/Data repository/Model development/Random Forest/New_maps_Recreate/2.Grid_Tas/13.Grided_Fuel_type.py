import pandas as pd

# Define file paths
fuel_type_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\9_Fuel_type_Tas.csv'
nearest_points_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\additional\Nearest_points_Fuel_type.csv'
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\13_Grided_Fuel_type.csv'

# Load CSV files into dataframes
fuel_type_df = pd.read_csv(fuel_type_file)
nearest_points_df = pd.read_csv(nearest_points_file)

# Convert lat and lon columns to string with 6 decimal points
fuel_type_df['Lat'] = fuel_type_df['Lat'].apply(lambda x: '{:.3f}'.format(x))
fuel_type_df['Lon'] = fuel_type_df['Lon'].apply(lambda x: '{:.3f}'.format(x))
nearest_points_df['Lat'] = nearest_points_df['Lat'].apply(lambda x: '{:.3f}'.format(x))
nearest_points_df['Lon'] = nearest_points_df['Lon'].apply(lambda x: '{:.3f}'.format(x))

# Merge dataframes on 'lat' and 'lon' columns to find matching points
merged_df = pd.merge(fuel_type_df, nearest_points_df, on=['Lat', 'Lon'], how='inner')

# Select desired columns
output_df = merged_df[[ 'Lat', 'Lon', 'Lat', 'Lon', 'Fuel_type']]

# Write to CSV
output_df.to_csv(output_file, index=False)

print(f"Filtered data written to '{output_file}'.")


import pandas as pd

# Define file paths
dry_days_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\1_Dry_days_random.CSV'
fmi_file = r'E:\Ignition Modelling project\Lightning_FMC_Project\2.Data\FMI-on lightning days\1.All_FMI_on_single_file.CSV'
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\2_FMIs_on_dry_days.CSV'

# Read dry days data
dry_days_df = pd.read_csv(dry_days_file)

# Read FMI data
fmi_df = pd.read_csv(fmi_file)

# Merge based on YYYYMMDD column
merged_df = pd.merge(dry_days_df, fmi_df, on='YYYYMMDD', how='inner')

# Write merged data to output CSV file
merged_df.to_csv(output_file, index=False)



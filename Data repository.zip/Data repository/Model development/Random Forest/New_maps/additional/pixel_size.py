from geopy.distance import geodesic

# Sample latitude and longitude coordinates
coordinates = [
    (-39.91666632743015, 143.83500033866667),
    (-39.91749966076347, 143.83500033866667),
    (-39.91833299409679, 143.83500033866667),
    (-39.919166327430105, 143.83500033866667),
    (-39.91999966076342, 143.83500033866667),
    (-39.91583299409683, 143.835833672),
    (-39.91666632743015, 143.835833672),
    (-39.91749966076347, 143.835833672),
    (-39.91833299409679, 143.835833672),
    (-39.919166327430105, 143.835833672),
    (-39.91999966076342, 143.835833672),
    (-39.92083299409674, 143.835833672),
    (-39.92166632743006, 143.835833672)
]

# Calculate distances between consecutive points
distances = [geodesic(coordinates[i], coordinates[i+1]).meters for i in range(len(coordinates)-1)]

# Calculate average distance
average_distance = sum(distances) / len(distances)

print(f"Average distance between points: {average_distance} meters")


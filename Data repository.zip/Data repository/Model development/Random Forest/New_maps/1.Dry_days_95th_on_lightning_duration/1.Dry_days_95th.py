import pandas as pd

# Load the CSV file
file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\32.LIE_vs_FMI_5th_percentile\1_Daily FMI_5th percentile withing TAS bounday.CSV'
df = pd.read_csv(file_path)

# Convert 'YYYYMMDD' column to datetime format with 'YYYYMMDD' format
df['YYYYMMDD'] = pd.to_datetime(df['YYYYMMDD'], format='%Y%m%d').dt.strftime('%Y%m%d')

# Filter the dataframe based on conditions
filtered_df = df[(df['YYYYMMDD'] >= '20040811') & (df['YYYYMMDD'] <= '20181231') & (df['5th_percentile_FMI'] < 11.6)]

# Create a new dataframe with only 'YYYYMMDD' column
result_df = filtered_df[['YYYYMMDD']]

# Save the result to a new CSV file
output_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\1.Dry_days_95th_on_lightning_duration\1_Dry_days_95th.CSV'
result_df.to_csv(output_file_path, index=False)


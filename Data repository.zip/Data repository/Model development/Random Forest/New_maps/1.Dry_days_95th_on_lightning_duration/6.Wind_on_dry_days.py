import pandas as pd
import numpy as np

# Path to U_wind and V_wind CSV files
u_wind_file = r'E:\Ignition Modelling project\Data\Wind direction\barra_ta_grids\U_data\U_wind_on_dry_days\2_U_wind_single_file_dry_days.csv'
v_wind_file = r'E:\Ignition Modelling project\Data\Wind direction\barra_ta_grids\V_data\V_wind_on_dry_days\2_V_wind_single_file_dry_days.csv'

# Read U_wind and V_wind CSV files
u_wind_df = pd.read_csv(u_wind_file)
v_wind_df = pd.read_csv(v_wind_file)

# Calculate wind speed and direction
wind_speed = np.sqrt(u_wind_df['U_wind']**2 + v_wind_df['V_wind']**2)
wind_direction = np.arctan2(v_wind_df['V_wind'], u_wind_df['U_wind']) * (180 / np.pi)

# Create a new DataFrame for wind data
wind_data = pd.DataFrame({
    'YYYYMMDD': u_wind_df['YYYYMMDD'],
    'lat': u_wind_df['lat'],
    'lon': u_wind_df['lon'],
    'Wind_speed': wind_speed,
    'Wind_direction': wind_direction
})

# Path to output CSV file
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\1.Dry_days_95th_on_lightning_duration\6_Wind_on_dry_days.csv'

# Save wind data to the output CSV file
wind_data.to_csv(output_file, index=False)



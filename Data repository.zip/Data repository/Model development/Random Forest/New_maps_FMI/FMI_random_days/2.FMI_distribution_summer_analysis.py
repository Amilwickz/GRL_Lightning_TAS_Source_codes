import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# Read the CSV file
data = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_FMI\FMI_random_days\1_FMI_distribution_summer.CSV')

# Calculate the percentile values (0.05, 0.10, 0.15, 0.25, 0.5, 0.75)
fmi_percentiles = data['FMI'].quantile([0.05, 0.10, 0.15, 0.25, 0.5, 0.75])

# Calculate the maximum, minimum, and average FMI values
fmi_max = data['FMI'].max()
fmi_min = data['FMI'].min()
fmi_mean = data['FMI'].mean()

print(fmi_max)
print(fmi_min)
print(fmi_mean)

# Plot the data with dotted plots and linear trendlines
plt.figure(figsize=(7.2, 4.8))

# Plot the normal distribution curve
mu, sigma = stats.norm.fit(data['FMI'])
x = np.linspace(data['FMI'].min(), data['FMI'].max(), 100)
pdf = stats.norm.pdf(x, mu, sigma)
plt.plot(x, pdf, color='blue', linestyle='-', label='Normal Distribution')

# Plot Q1 (25th percentile)
percentile_25_x = fmi_percentiles[0.25]
plt.axvline(x=percentile_25_x, ymin=0, ymax=0.697, color='green', linestyle='--', label=f'Q1 (25th Percentile): {percentile_25_x:.2f}', linewidth=1)

# Plot Q2 (median)
percentile_50_x = fmi_percentiles[0.5]
plt.axvline(x=percentile_50_x, ymin=0, ymax=0.922, color='green', linestyle='--', label=f'Q2 (Median): {percentile_50_x:.2f}', linewidth=1)

# Plot Q3 (75th percentile)
percentile_75_x = fmi_percentiles[0.75]
plt.axvline(x=percentile_75_x, ymin=0, ymax=0.7, color='green', linestyle='--', label=f'Q3 (75th Percentile): {percentile_75_x:.2f}', linewidth=1)

# Fill area under the normal distribution curve and less than the 25th percentile dashed line
plt.fill_between(x, pdf, where=(x < fmi_percentiles[0.25]), color='red', alpha=0.5, zorder=50)

# Customize plot axes labels
plt.xlabel('FMI')
plt.ylim(0,0.1)
plt.ylabel('Probability Density')

# Add maximum, minimum, and average FMI values to the plot
plt.axvline(x=fmi_max, color='red', linestyle='--', label=f'Max FMI: {fmi_max:.2f}', linewidth=1)
plt.axvline(x=fmi_min, color='blue', linestyle='--', label=f'Min FMI: {fmi_min:.2f}', linewidth=1)
plt.axvline(x=fmi_mean, color='purple', linestyle='--', label=f'Mean FMI: {fmi_mean:.2f}', linewidth=1)

# Increase axis thickness
plt.gca().spines['bottom'].set_linewidth(2)
plt.gca().spines['left'].set_linewidth(2)

# Add legend
plt.legend(fontsize=10)

# Remove borders
sns.despine()

# Save the plot
plt.savefig(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_FMI\FMI_random_days\9_2.png', format='png')

# Show the plot
plt.show()


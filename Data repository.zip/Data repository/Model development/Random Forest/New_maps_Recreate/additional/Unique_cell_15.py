import pandas as pd

# Load the CSV file
file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\15_Grided_Fuel_type_encoded.CSV'
df = pd.read_csv(file_path)

# Find unique records based on 'Lat' and 'Lon' columns together
unique_records = df.drop_duplicates(subset=['Lat', 'Lon'])

# Write unique records to Unique_cell_15.CSV
output_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\additional\Unique_cell_15.CSV'
unique_records.to_csv(output_path, index=False)

print(f'Unique records based on Lat and Lon have been written to: {output_path}')

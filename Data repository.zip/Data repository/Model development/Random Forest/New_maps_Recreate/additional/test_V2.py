import pandas as pd

# Define file path
input_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\11_Grided_Fuel_arranged.CSV'

# Read CSV file into a pandas dataframe
data_df = pd.read_csv(input_file)

# Calculate the average value of the 'Fuel_Load' column
average_fuel_load = data_df['Fuel_Load'].mean()

print(f"The average Fuel Load is: {average_fuel_load}")


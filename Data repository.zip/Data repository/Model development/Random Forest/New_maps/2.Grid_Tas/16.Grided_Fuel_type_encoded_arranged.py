import pandas as pd

# Load Unique_cell_15_V2.CSV
unique_cell_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\Unique_cell_15_V2.CSV'
unique_cell_df = pd.read_csv(unique_cell_path)

# Load 1_Grid_Tas.CSV
grid_tas_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\1_Grid_Tas.CSV'
grid_tas_df = pd.read_csv(grid_tas_path)

# Write Unique_cell_15_V2.CSV records to 16_Grided_Fuel_type_encoded_arranged.CSV
output_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\16_Grided_Fuel_type_encoded_arranged.CSV'
unique_cell_df.to_csv(output_path, index=False)

# Find records in grid_tas_df that are not in unique_cell_df based on 'Lat' and 'Lon'
non_unique_records = grid_tas_df[~grid_tas_df.set_index(['Lat', 'Lon']).index.isin(unique_cell_df.set_index(['Lat', 'Lon']).index)]

# Append non-unique records to 16_Grided_Fuel_type_encoded_arranged.CSV
non_unique_records.to_csv(output_path, mode='a', index=False, header=False)

print(f'All records from Unique_cell_15_V2.CSV and non-unique records from 1_Grid_Tas.CSV have been written to: {output_path}')

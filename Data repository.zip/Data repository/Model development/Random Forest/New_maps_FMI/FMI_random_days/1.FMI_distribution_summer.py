import pandas as pd

# Define the input and output file paths
input_csv = r'E:\Ignition Modelling project\Lightning_FMC_Project\2.Data\FMI-on lightning days\1.All_FMI_on_single_file.CSV'
output_csv = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_FMI\FMI_random_days\1_FMI_distribution_summer.CSV'

# Read the CSV file
df = pd.read_csv(input_csv)

# Convert the 'YYYYMMDD' column to string type to easily extract month part
df['YYYYMMDD'] = df['YYYYMMDD'].astype(str)

# Extract the month part from 'YYYYMMDD' column
df['MM'] = df['YYYYMMDD'].str[4:6]

# Filter records where month is November (11), December (12), January (01), February (02), or March (03) <------Summer months based on the FMC work
filtered_df = df[df['MM'].isin(['11', '12', '01', '02', '03'])]

# Drop the 'MM' column as it's no longer needed
filtered_df = filtered_df.drop(columns=['MM'])

# Save the filtered records to a new CSV file
filtered_df.to_csv(output_csv, index=False)

import pandas as pd

# Define the file paths
input_file = r'E:\Ignition Modelling project\Data\Fuel data\OutputFiles_of_3_Coordinate_data_Fuel_load_Tasmania_TIF_annual\Merging_Fuel_data_2000_2023.CSV'
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\1.Dry_days_95th_on_lightning_duration\8_Fuel_Tas.CSV'

# Read the CSV file into a DataFrame
df = pd.read_csv(input_file)

# Convert 'YYYYMMDD' column to datetime format
df['YYYYMMDD'] = pd.to_datetime(df['YYYYMMDD'], format='%Y%m%d')

# Filter records with Fuel_Load > 0 and within the specified date range
filtered_df = df[(df['Fuel_Load'] > 0) & (df['YYYYMMDD'].between('2003-12-31', '2018-12-31'))]

# Convert the 'YYYYMMDD' column back to the required format (YYYYMMDD as string)
filtered_df['YYYYMMDD'] = filtered_df['YYYYMMDD'].dt.strftime('%Y%m%d')

# Write the filtered DataFrame to a new CSV file
filtered_df.to_csv(output_file, index=False)

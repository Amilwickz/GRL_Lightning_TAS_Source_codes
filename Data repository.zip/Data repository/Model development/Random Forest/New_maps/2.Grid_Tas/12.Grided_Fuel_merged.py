import pandas as pd

# Load the CSV files into pandas dataframes
grided_fuel_arranged = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\11_Grided_Fuel_arranged.CSV')
missing_records = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\missing_records.CSV')

# Merge the two dataframes
merged_df = pd.concat([grided_fuel_arranged, missing_records])

# Arrange the data in ascending order according to the 'Year' column
merged_df_sorted = merged_df.sort_values(by='YYYYMMDD')

# Rename the 'Year' column as 'YYYYMMDD'
merged_df_sorted.rename(columns={'YYYYMMDD': 'YYYYMMDD'}, inplace=True)

# Save the merged and sorted dataframe to CSV
merged_df_sorted.to_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\12_Grided_Fuel_merged.CSV', index=False)


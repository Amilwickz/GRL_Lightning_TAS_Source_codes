import pandas as pd

# Load Unique_cell_15.CSV
unique_cell_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\additional\Unique_cell_15.CSV'
unique_cell_df = pd.read_csv(unique_cell_path)

# Load 1_Grid_Tas.CSV
grid_tas_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\1_Grid_Tas.CSV'
grid_tas_df = pd.read_csv(grid_tas_path)

# Merge the dataframes based on 'Lat' and 'Lon'
merged_df = pd.merge(unique_cell_df, grid_tas_df, on=['Lat', 'Lon'], how='inner')

# Write the unique records to Unique_cell_15_V2.CSV
output_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\additional\Unique_cell_15_V2.CSV'
merged_df.to_csv(output_path, index=False)

print(f'Unique records based on Lat and Lon from Unique_cell_15.CSV and 1_Grid_Tas.CSV have been written to: {output_path}')

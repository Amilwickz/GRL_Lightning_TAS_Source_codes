import csv
import rasterio
import numpy as np


# Function to read elevation data from the TIF file
def read_elevation_from_tif(tif_file, lat, lon):
    with rasterio.open(tif_file) as dataset:
        # Get the row and column indices corresponding to the given lat, lon
        row, col = dataset.index(lon, lat)
        # Read a small window of elevation data around the specified row and column
        elevation_window = dataset.read(1, window=((row - 1, row + 2), (col - 1, col + 2)))
    return elevation_window


# Function to calculate slope
def calculate_slope(elevation_window):
    dz_dx = np.gradient(elevation_window, axis=0)
    dz_dy = np.gradient(elevation_window, axis=1)
    slope_rad = np.arctan(np.sqrt(dz_dx ** 2 + dz_dy ** 2))
    slope_deg = np.degrees(slope_rad)
    return np.mean(slope_deg)  # Taking the mean slope value in the window


# Path to the TIF file containing elevation data
tif_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 2_Lightning\Elevation data-lightning\SRTM_mosaic2.TIF'

# Path to the input CSV file containing Lat, Lon data
input_csv_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\5_Grided_Elevation.csv'

# Path to store the new CSV file with slope data
output_csv_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\6_Grided_Slope.csv'


# Read the Lat, Lon data from the input CSV file
lat_lon_elevation_points = []
with open(input_csv_file_path, 'r') as input_csv_file:
    csv_reader = csv.DictReader(input_csv_file)
    for row in csv_reader:
        lat = float(row['Lat'])
        lon = float(row['Lon'])
        lat_lon_elevation_points.append((lat, lon))


# Calculate slope for each Lat, Lon point and write to the output CSV file
with open(output_csv_file_path, 'w', newline='') as output_csv_file:
    fieldnames = ['Lat', 'Lon', 'Slope']
    csv_writer = csv.DictWriter(output_csv_file, fieldnames=fieldnames)
    csv_writer.writeheader()

    for lat, lon in lat_lon_elevation_points:
        # Read elevation data from the TIF file
        elevation_window = read_elevation_from_tif(tif_file_path, lat, lon)

        # Calculate slope
        slope = calculate_slope(elevation_window)

        # Write to CSV
        csv_writer.writerow({'Lat': lat, 'Lon': lon, 'Slope': slope})

print(f"Slope data calculated and written to '{output_csv_file_path}'.")


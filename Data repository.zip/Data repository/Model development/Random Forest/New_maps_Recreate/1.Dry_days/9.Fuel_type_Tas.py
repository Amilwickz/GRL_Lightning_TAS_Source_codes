import pandas as pd

# Load the CSV file
csv_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\Fuel data-lightning\Fuel type\1_Fuel types_Tasmania_Raw data.CSV'
data = pd.read_csv(csv_file)

# Check if 'Fuel_type' contains only numbers
filtered_data = data[data['Fuel_type'].apply(lambda x: str(x).replace('.', '').isdigit())]

# Write the filtered data to a new CSV file
output_csv = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\9_Fuel_type_Tas.CSV'
filtered_data.to_csv(output_csv, index=False)

print("Filtered data has been written to", output_csv)


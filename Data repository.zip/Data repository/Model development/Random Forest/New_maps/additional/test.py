import pandas as pd

# Load the CSV file
file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\Predicted probability maps\1_predicted_probability.csv'
data = pd.read_csv(file_path)

# Find the maximum and minimum values of the 'Predicted Probability' column
max_value = data['Predicted Probability'].max()
min_value = data['Predicted Probability'].min()

print("Maximum Predicted Probability:", max_value)
print("Minimum Predicted Probability:", min_value)


import geopandas as gpd
import pandas as pd

# Define file paths
all_data_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\3.Merging_files\3_All_data.CSV'
tasmania_shapefile = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\Creating Tas plain shapefile\Tasmania_plain.shp'
output_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\3.Merging_files\4_All_data_Tas_boundary.CSV'

# Read Tasmania shapefile
tasmania = gpd.read_file(tasmania_shapefile)

# Read All Data CSV file
all_data_df = pd.read_csv(all_data_path)

# Create a geometry column in the All Data DataFrame using the Lat and Lon columns
all_data_df['geometry'] = gpd.points_from_xy(all_data_df['Lon'], all_data_df['Lat'])

# Convert All Data DataFrame to a GeoDataFrame
gdf_all_data = gpd.GeoDataFrame(all_data_df, crs=tasmania.crs, geometry='geometry')

# Spatially join to filter records within Tasmania boundary
tasmania_boundary_data = gpd.sjoin(gdf_all_data, tasmania, op='within')

# Drop unnecessary columns from the result
tasmania_boundary_data = tasmania_boundary_data[['YYYYMMDD', 'Lat', 'Lon', 'FMI', 'SDI','FFDI', 'radiation', 'Fuel_Load', 'Wind_speed', 'Wind_direction', 'Elevation', 'Slope', 'Aspect', 'TPI', 'Fuel_type', '1', '2', '3', '4']]

# Write filtered data to new CSV file
tasmania_boundary_data.to_csv(output_path, index=False)

# Print number of records within Tasmania boundary
print(f'Number of records within Tasmania boundary: {len(tasmania_boundary_data)}')

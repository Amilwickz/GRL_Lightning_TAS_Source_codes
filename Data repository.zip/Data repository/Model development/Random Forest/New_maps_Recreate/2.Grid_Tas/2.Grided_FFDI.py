import pandas as pd

# Define file paths
ffd_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\4_FFDIs_on_dry_days.csv'
nearest_points_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\additional\Nearest_points_FFDI.csv'
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\2_Grided_FFDI.csv'

# Load CSV files into dataframes
ffd_df = pd.read_csv(ffd_file)
nearest_points_df = pd.read_csv(nearest_points_file)

# Convert lat and lon columns to string with 6 decimal points
ffd_df['lat'] = ffd_df['lat'].apply(lambda x: '{:.13f}'.format(x))
ffd_df['lon'] = ffd_df['lon'].apply(lambda x: '{:.12f}'.format(x))
nearest_points_df['lat'] = nearest_points_df['lat'].apply(lambda x: '{:.13f}'.format(x))
nearest_points_df['lon'] = nearest_points_df['lon'].apply(lambda x: '{:.12f}'.format(x))

# Merge dataframes on 'lat' and 'lon' columns to find matching points
merged_df = pd.merge(ffd_df, nearest_points_df, on=['lat', 'lon'], how='inner')

# Select desired columns
output_df = merged_df[['YYYYMMDD', 'lat', 'lon', 'Lat', 'Lon', 'FFDI']]

# Write to CSV
output_df.to_csv(output_file, index=False)

print(f"Filtered data written to '{output_file}'.")


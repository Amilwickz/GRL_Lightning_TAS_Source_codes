import pandas as pd

# Define the file paths
input_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\5.Proba_maps\3_Probability_mean.CSV'
output_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\5.Proba_maps\4_Probability_mean_adjust.CSV'

# Load the CSV file into a DataFrame
df = pd.read_csv(input_file_path)

# Define the prior probability P(Occurrence)
P_Occurrence = 244 / (21745 + 244)
P_Not_Occurrence = 1 - P_Occurrence


# Function to adjust the predicted probability using Bayes' theorem
def bayes_adjustment(P_Model):
    P_Data_given_Occurrence = P_Model
    P_Data_given_Not_Occurrence = 1 - P_Model

    P_Data = (P_Data_given_Occurrence * P_Occurrence) + (P_Data_given_Not_Occurrence * P_Not_Occurrence)

    P_Occurrence_given_Data = (P_Data_given_Occurrence * P_Occurrence) / P_Data
    return P_Occurrence_given_Data


# Apply the function to each row in the DataFrame
df['Bayes Predicted Probability'] = df['Mean Predicted Probability'].apply(bayes_adjustment)

# Save the updated DataFrame to a new CSV file
df.to_csv(output_file_path, index=False)

print(f"Adjusted probabilities saved to {output_file_path}")

import pandas as pd

# Define file paths
met_fuel_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\3.Merging_files\1_Met_fuel_files.CSV'
topography_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\3.Merging_files\2_Topography_files.CSV'
output_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\3.Merging_files\3_All_data.CSV'

# Read CSV files into pandas DataFrames
met_fuel_df = pd.read_csv(met_fuel_path)
topography_df = pd.read_csv(topography_path)

# Merge based on matching 'Lat' and 'Lon' columns
merged_df = pd.merge(met_fuel_df, topography_df, on=['Lat', 'Lon'], how='inner')

# Write merged data to new CSV file
merged_df.to_csv(output_path, index=False)

# Print number of matching records
print(f'Number of matching records: {len(merged_df)}')

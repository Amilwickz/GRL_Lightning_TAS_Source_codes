import pandas as pd

# Load the CSV file into a pandas dataframe
grided_fuel_type_df = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\13_Grided_Fuel_type.CSV')

# Define a function to map numbers to names and categories
def map_fuel_type(number):
   if number in [1, 4, 5, 6, 13, 23]:
       return 'ClosedForest', 1
   elif number in [3, 9, 14, 15, 22, 24]:
       return 'OpenForest', 2
   elif number in [7, 8, 10, 11, 12, 16, 18, 20, 21]:
       return 'Treeless', 3
   elif number in [2, 17, 19]:
       return 'Other', 4
   else:
       return 'Unknown', None

# Apply the mapping function to the 'Fuel_type' column and create the 'Category' column
grided_fuel_type_df['Fuel_type'], grided_fuel_type_df['Category'] = zip(*grided_fuel_type_df['Fuel_type'].apply(map_fuel_type))

# Create a new dataframe with the required columns
new_df = grided_fuel_type_df[['Lat', 'Lon', 'Fuel_type', 'Category']]

# Write the new dataframe to a CSV file
output_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\14_Grided_Fuel_type_names.CSV'
new_df.to_csv(output_file_path, index=False)

print(f"CSV file with mapped Fuel_type names and Category column has been created at: {output_file_path}")

import pandas as pd

# Read the original CSV file
csv_file = r'C:/Users/amilaw/Desktop/Ignition Modelling project/Data/Data summary 3_Lightning/ZZ_Model_development/ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI/Random Forest/New_maps/5.Predicted_probability_maps/2_Probability_cellsBlocks.CSV'
df = pd.read_csv(csv_file)

# Group by grid cells and calculate the mean 'Predicted Probability'
grouped_df = df.groupby(['Lower_Latitude', 'Higher_Latitude', 'Lower_Longitude', 'Higher_Longitude'])['Predicted Probability'].mean().reset_index()

# Rename the column to 'Mean Predicted Probability'
grouped_df.rename(columns={'Predicted Probability': 'Mean Predicted Probability'}, inplace=True)

# Check if 'Mean Predicted Probability' is zero and add 0.000001 if so
grouped_df.loc[grouped_df['Mean Predicted Probability'] == 0, 'Mean Predicted Probability'] += 0.000001

# Save the result to a new CSV file
output_file = r'C:/Users/amilaw/Desktop/Ignition Modelling project/Data/Data summary 3_Lightning/ZZ_Model_development/ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI/Random Forest/New_maps/5.Predicted_probability_maps/3_Probability_mean.CSV'
grouped_df.to_csv(output_file, index=False)

print(f"Unique cells data saved to {output_file}")

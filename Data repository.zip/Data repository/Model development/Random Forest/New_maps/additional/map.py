import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
import numpy as np


# Load the CSV file containing grid cell information and mean predicted probabilities
csv_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\5.Predicted_probability_maps\3_Probability_mean.csv'
df = pd.read_csv(csv_file)

# Calculate center coordinates of grid cells
df['Center_Latitude'] = (df['Lower_Latitude'] + df['Higher_Latitude']) / 2
df['Center_Longitude'] = (df['Lower_Longitude'] + df['Higher_Longitude']) / 2

# Calculate log transformed values of 'Mean Predicted Probability'
df['Log_Mean_Predicted_Probability'] = np.log(df['Mean Predicted Probability'])

# Print the maximum and minimum log transformed 'Mean Predicted Probability' values
max_log_value = df['Log_Mean_Predicted_Probability'].max()
min_log_value = df['Log_Mean_Predicted_Probability'].min()
print(f"Maximum Log Transformed Mean Predicted Probability: {max_log_value}")
print(f"Minimum Log Transformed Mean Predicted Probability: {min_log_value}")

# Define color thresholds and corresponding colors for log transformed values
log_thresholds = [-1.7, -1.5, -1.3, -1.1, -0.9, 0.7]
log_colors = ['#FFF3B2', '#FEB24C', '#FC4E2A', '#E31A1C', '#B10026']

# Assign colors based on log transformed 'Mean Predicted Probability' values
df['Color'] = pd.cut(df['Log_Mean_Predicted_Probability'], bins=log_thresholds, labels=log_colors)

# Read the Tasmania shapefile
shapefile = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Lightning_FMC_Project\2.Data\Shapefiles\Creating Tas plain shapefile\Tasmania_plain.shp'
gdf_tasmania = gpd.read_file(shapefile)

# Plot the markers on the map
fig, ax = plt.subplots(figsize=(10, 10))
gdf_tasmania.boundary.plot(ax=ax, linewidth=0.5)  # Plot the boundary
gdf_tasmania.plot(ax=ax, facecolor='none')  # Plot the shapefile
df.plot(ax=ax, kind='scatter', x='Center_Longitude', y='Center_Latitude', color=df['Color'], alpha=0.7)

# Create a legend
legend_labels = ['-2.5 to -2.0', '-2.0 to -1.5', '-1.5 to -1.0', '-1.0 to -0.5', '-0.5 to 0.0']
legend_handles = [
    plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=color, markersize=10, label=label)
    for color, label in zip(log_colors, legend_labels)
]
plt.legend(handles=legend_handles, loc='upper left', title='Log Transformed Mean Predicted Probability Range')

# Set plot title and labels
plt.title('Log Transformed Mean Predicted Probability Distribution in Tasmania')
plt.xlabel('Longitude')
plt.ylabel('Latitude')

# Show the plot
plt.show()


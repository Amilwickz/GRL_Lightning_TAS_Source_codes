import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load the CSV file into a DataFrame
file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\Z_summing_data\Z_summing_data_including_Type_fuel-4-category_TPI\5_Binary_classification_dry_lightning_Aug_2004_to_Dec_2022.csv'

# Specify the columns of interest
columns_of_interest = ['Aspect', 'Elevation', 'FFDI', 'Slope', 'fuel load', 'RH', 'solar_rad', 'max_temp', 'vp_deficit', 'wind_speed', 'wind_direction', 'FMI', 'SDI', 'TPI', '1', '2', '3', '4']

# Read only the specified columns from the CSV file
df = pd.read_csv(file_path, usecols=columns_of_interest)

# Calculate the correlation matrix
correlation_matrix = df.corr()


# Visualize the correlation matrix using a heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", cbar_kws={'orientation': 'vertical'}, annot_kws={"size": 14})
plt.xticks(rotation=45, ha='right')
plt.yticks(rotation=45)
plt.title('Correlation Matrix Heatmap')
plt.show()

# Set the correlation threshold
correlation_threshold = 0.75

# Identify highly correlated variables
highly_correlated_pairs = []
for i in range(len(correlation_matrix.columns)):
    for j in range(i):
        if abs(correlation_matrix.iloc[i, j]) >= correlation_threshold:
            col_name_i = correlation_matrix.columns[i]
            col_name_j = correlation_matrix.columns[j]
            highly_correlated_pairs.append((col_name_i, col_name_j))

# Print the highly correlated variable pairs
print("Highly correlated variable pairs with a correlation threshold of", correlation_threshold)
for pair in highly_correlated_pairs:
    print(pair)

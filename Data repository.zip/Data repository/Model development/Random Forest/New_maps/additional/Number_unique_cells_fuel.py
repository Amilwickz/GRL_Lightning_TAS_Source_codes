import pandas as pd

# Path to the CSV file containing Lat and Lon coordinates for dry_days_cells
dry_days_cells_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\dry_days_cells.csv'

# Path to the CSV file containing Lat and Lon coordinates for 9_Grided_Fuel
grided_fuel_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\9_Grided_Fuel.csv'

# Read CSV files into pandas dataframes
dry_days_cells_df = pd.read_csv(dry_days_cells_file)
grided_fuel_df = pd.read_csv(grided_fuel_file)

# Get unique cells with the same Lat and Lon coordinates from dry_days_cells
unique_cells_dry_days = dry_days_cells_df[['Lat', 'Lon']].drop_duplicates()

# Get unique cells with the same Lat and Lon coordinates from 9_Grided_Fuel
unique_cells_grided_fuel = grided_fuel_df[['Lat', 'Lon']].drop_duplicates()

# Find the intersection of unique cells between the two dataframes
common_cells = pd.merge(unique_cells_dry_days, unique_cells_grided_fuel, on=['Lat', 'Lon'])

# Get the number of common cells
num_common_cells = len(common_cells)

print(f"Number of unique cells with the same Lat and Lon coordinates in both files: {num_common_cells}")


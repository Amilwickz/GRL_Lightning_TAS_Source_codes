import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.inspection import PartialDependenceDisplay
from imblearn.under_sampling import RandomUnderSampler
from sklearn.impute import SimpleImputer

# Load the data from the CSV file
data = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\Z_summing_data\Z_summing_data_including_Type_fuel-4-category_TPI\4_Binary_classification_dry_lightning_Aug_2004_to_Dec_2018.CSV')

# Select the relevant columns
selected_columns = ['Aspect', 'Elevation', 'Slope', 'TPI','fuel load', '1', '2', '3', '4', 'FMI', 'SDI',  'FFDI', 'solar_rad','wind_speed', 'wind_direction', 'Binary']
data = data[selected_columns]

# Split the data into features and target
X = data.drop('Binary', axis=1)
y = data['Binary']

# Use RandomUnderSampler to balance the class distribution (optional, depending on your data)
rus = RandomUnderSampler(random_state=42)
X_resampled, y_resampled = rus.fit_resample(X, y)

# Split the resampled data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.3, random_state=42)

# Impute missing values with the mean
imputer = SimpleImputer(strategy='mean')
X_train = imputer.fit_transform(X_train)
X_test = imputer.transform(X_test)

# Create a Random Forest model
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train, y_train)

# Define feature labels for plotting
feature_labels = ['Aspect', 'Elevation', 'Slope','TPI', 'Fuel load', '1', '2', '3', '4', 'FMI', 'SDI', 'FFDI', 'solar_rad', 'wind_speed', 'wind_direction']

# Plot partial dependence for all features except '1', '2', '3', '4'
fig, axes = plt.subplots(nrows=5, ncols=3, figsize=(12, 8))

# Define the order of features to be plotted
plot_order = ['Aspect', 'Elevation', 'Slope','TPI', 'Fuel load', 'FMI', 'SDI', 'FFDI', 'solar_rad', 'wind_speed', 'wind_direction']

# Set the same y-axis limits for each subplot
y_min, y_max = 0, 0.8  # Example limits, adjust as needed

# Define colors for different sets of features
colors = {
    'Aspect': '#d47264',
    'Elevation': '#d47264',
    'Slope': '#d47264',
    'TPI':'#d47264',
    'Fuel load': '#59a89c',
    'FMI': '#59a89c',
    'SDI': '#2066a8',
    'FFDI': '#2066a8',
    'solar_rad': '#2066a8',
    'wind_speed': '#2066a8',
    'wind_direction': '#2066a8'
}

for i, feature in enumerate(plot_order):
    ax = axes.flatten()[i]
    display = PartialDependenceDisplay.from_estimator(
        estimator=rf_model,
        X=X_test,
        features=[feature_labels.index(feature)],
        response_method='predict_proba',
        ax=ax,
        line_kw={'linewidth':3}
    )
    display.plot(ax=display.axes_)  # Use default color
    ax.set_title(feature)
    ax.set_xlabel('')
    ax.set_ylabel('')
    ax.xaxis.set_tick_params(rotation=45)

    # Set y-axis limits globally for all subplots
    ax.set_ylim(y_min, y_max)

    # Set color for specific features if there are lines in the plot
    if ax.get_lines():
        ax.get_lines()[0].set_color(colors[feature])

# Hide remaining axes in the subplot grid
for j in range(len(plot_order), len(axes.flatten())):
    axes.flatten()[j].axis('off')

plt.tight_layout()
plt.show()


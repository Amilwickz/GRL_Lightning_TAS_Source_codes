import pandas as pd
from sklearn.impute import SimpleImputer
import joblib

# Load the new data
new_data = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\3.Merging_files\5_All_data_Tas_boundary.CSV')

# Select the relevant columns excluding 'Fuel_type' and '1', '2', '3', '4'
selected_columns_new = ['FMI', 'SDI', 'FFDI', 'solar_rad', 'fuel load', 'wind_speed', 'wind_direction', 'Elevation', 'Slope', 'Aspect', 'TPI', '1', '2', '3', '4']
new_data_model = new_data[selected_columns_new]

# Impute missing values with the mean for the new data
imputer = SimpleImputer(strategy='mean')
new_data_model = imputer.fit_transform(new_data_model)

# Load the trained model
best_model_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\4.Trained model\best_trained_model.pkl'
best_model = joblib.load(best_model_path)

# Use the trained model to predict probabilities for the new data
predicted_probabilities_new = best_model.predict_proba(new_data_model)[:, 1]

# Add predicted probabilities to the new data
new_data['Predicted Probability'] = predicted_probabilities_new

# Save the updated data to a new CSV file
output_path_new = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\5.Predicted_probability_maps\1_predicted_probability.csv'
new_data.to_csv(output_path_new, index=False)

print(f"Predicted probabilities for new data saved to: {output_path_new}")


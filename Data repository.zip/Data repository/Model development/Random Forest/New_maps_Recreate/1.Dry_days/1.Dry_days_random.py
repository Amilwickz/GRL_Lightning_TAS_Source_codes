import pandas as pd
import numpy as np
import random

# Define the date range
start_date = '20040811'
end_date = '20181231'

# Generate a list of all dates within the range
date_range = pd.date_range(start=start_date, end=end_date)

# Convert the date range to the format YYYYMMDD
date_range_str = date_range.strftime('%Y%m%d')

# Randomly select 300 dates from the range
random_dates = random.sample(list(date_range_str), 300)

# Create a DataFrame with the selected dates
df_random_dates = pd.DataFrame(random_dates, columns=['YYYYMMDD'])

# Sort the DataFrame in ascending order
df_random_dates_sorted = df_random_dates.sort_values(by='YYYYMMDD').reset_index(drop=True)

# Write the sorted DataFrame to a CSV file
output_csv_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\1_Dry_days_random.CSV'
df_random_dates_sorted.to_csv(output_csv_path, index=False)


import pandas as pd

# Define file paths
input_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\1.Dry_days_95th_on_lightning_duration\5_Solar_on_dry_days.csv'
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\additional\5_Solar_on_dry_days-unique.csv'

# Read CSV file into a pandas dataframe
data_df = pd.read_csv(input_file)

# Extract unique latitudes and longitudes
unique_points = data_df[['lat', 'lon']].drop_duplicates()

# Write to CSV
unique_points.to_csv(output_file, index=False)

print(f"Unique latitudes and longitudes written to '{output_file}'.")


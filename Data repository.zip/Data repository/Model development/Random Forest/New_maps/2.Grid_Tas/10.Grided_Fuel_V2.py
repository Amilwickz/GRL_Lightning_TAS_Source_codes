import pandas as pd

# Load the CSV file into a pandas dataframe
grided_fuel = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\9_Grided_Fuel.CSV')

# Extract the year from the 'YYYYMMDD' column and create a new 'Year' column
grided_fuel['Year'] = grided_fuel['YYYYMMDD'].astype(str).str[:4]

# Rename the columns as per the requirement
grided_fuel = grided_fuel.rename(columns={'Lat': 'Lat', 'Lon': 'Lon', 'Fuel_Load': 'Fuel_Load'})

# Select the required columns in the desired order
grided_fuel = grided_fuel[['Year', 'Lat', 'Lon', 'Fuel_Load']]

# Save the modified dataframe to a new CSV file
grided_fuel.to_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\10_Grided_Fuel_V2.CSV', index=False)


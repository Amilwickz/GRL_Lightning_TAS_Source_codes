import pandas as pd
import matplotlib.pyplot as plt

# Load the data from the CSV file
data = pd.read_csv(r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type\Random Forest\8_Random Forest-Resampling-Hyperparameters-feature importance-V2.CSV')

# Define custom colors for feature importance plot
custom_colors = {
    'Aspect': '#d47264', 'Elevation': '#d47264', 'Slope': '#d47264',
    'Fuel load': '#59a89c', 'Fuel type': '#59a89c', 'FMI': '#59a89c',
    'SDI': '#2066a8', 'RH': '#2066a8', 'FFDI': '#2066a8',
    'Solar rad': '#2066a8', 'Max temp': '#2066a8',
    'Vapour press': '#2066a8', 'Wind speed': '#2066a8', 'Wind direction': '#2066a8'
}

# Sort the data by Importance column in ascending order
data_sorted = data.sort_values(by='Importance')

# Plot the feature importance bars in ascending order with custom colors
plt.figure(figsize=(10, 6))
plt.barh(data_sorted['Feature'], data_sorted['Importance'], color=[custom_colors[feature] for feature in data_sorted['Feature']])
plt.xlabel('Feature Importance', fontsize=16)
plt.ylabel('Feature', fontsize=16)
plt.title('Feature Importance Plot', fontsize=18)
plt.show()

import pandas as pd

# Define file paths
elevation_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\5_Grided_Elevation.CSV'
aspect_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\6_Grided_Slope.CSV'
slope_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\7_Grided_Aspect.CSV'
tpi_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\8_Grided_TPI.CSV'
fuel_type_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\16_Grided_Fuel_type_encoded_arranged.CSV'



output_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\3.Merging_files\2_Topography_files.CSV'

# Read CSV files into pandas DataFrames
elevation_df = pd.read_csv(elevation_path)
aspect_df = pd.read_csv(aspect_path)
slope_df = pd.read_csv(slope_path)
tpi_df = pd.read_csv(tpi_path)
fuel_type_df = pd.read_csv(fuel_type_path)

# Merge based on matching 'Lat', 'Lon' columns
merged_df = pd.merge(elevation_df, aspect_df, on=['Lat', 'Lon'], how='inner')
merged_df = pd.merge(merged_df, slope_df, on=['Lat', 'Lon'], how='inner')
merged_df = pd.merge(merged_df, tpi_df, on=['Lat', 'Lon'], how='inner')
merged_df = pd.merge(merged_df, fuel_type_df, on=['Lat', 'Lon'], how='inner')

# Select only the desired columns
merged_df = merged_df[['Lat', 'Lon', 'Elevation', 'Slope', 'Aspect', 'TPI','Fuel_type','1','2','3','4']]

# Write merged data to new CSV file
merged_df.to_csv(output_path, index=False)

# Print number of matching records
print(f'Number of matching records: {len(merged_df)}')

import csv
import numpy as np

# Function to calculate the Topographic Position Index (TPI)
def calculate_tpi(elevations):
    center = elevations[len(elevations) // 2]
    if np.isnan(center):
        return np.nan
    else:
        return center - np.nanmean(elevations)

# Path to the input CSV file containing Lat, Lon, and Elevation data
input_csv_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\5_Grided_Elevation.csv'

# Path to store the new CSV file with TPI data
output_csv_file_path = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\8_Grided_TPI.csv'

# Read the Lat, Lon, and Elevation data from the input CSV file
lat_lon_elevation_points = []
with open(input_csv_file_path, 'r') as input_csv_file:
    csv_reader = csv.DictReader(input_csv_file)
    for row in csv_reader:
        lat = float(row['Lat'])
        lon = float(row['Lon'])
        elevation = float(row['Elevation'])
        lat_lon_elevation_points.append((lat, lon, elevation))

# Calculate TPI for each Lat, Lon point and write to the output CSV file
with open(output_csv_file_path, 'w', newline='') as output_csv_file:
    fieldnames = ['Lat', 'Lon', 'TPI']
    csv_writer = csv.DictWriter(output_csv_file, fieldnames=fieldnames)
    csv_writer.writeheader()

    for lat, lon, elevation in lat_lon_elevation_points:
        # Assume a window size of 3x3 around the current location
        window_elevations = []
        for point in lat_lon_elevation_points:
            if abs(point[0] - lat) <= 1 and abs(point[1] - lon) <= 1:
                window_elevations.append(point[2])
        tpi = calculate_tpi(window_elevations)
        csv_writer.writerow({'Lat': lat, 'Lon': lon, 'TPI': tpi})

print(f"TPI data calculated and written to '{output_csv_file_path}'.")


import pandas as pd

# Load the CSV file
input_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\14_Grided_Fuel_type_names.csv'
df = pd.read_csv(input_file)

# Perform one-hot encoding
df_encoded = pd.get_dummies(df, columns=['Category'])

# Rename the new columns to '1', '2', ..., '24'
df_encoded.columns = df_encoded.columns.str.replace('Category_', '')

# Write the encoded DataFrame to a new CSV file
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps\2.Grid_Tas\15_Grided_Fuel_type_encoded.csv'
df_encoded.to_csv(output_file, index=False)

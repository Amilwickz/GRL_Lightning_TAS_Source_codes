import pandas as pd

# Define file paths
solar_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\1.Dry_days\5_Solar_on_dry_days.csv'
nearest_points_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\additional\Nearest_points_SolarRad.csv'
output_file = r'C:\Users\amilaw\Desktop\Ignition Modelling project\Data\Data summary 3_Lightning\ZZ_Model_development\ZZ_Model_development_including_FMI_FFDI_SDI_Fuel_type-4-category_TPI\Random Forest\New_maps_Recreate\2.Grid_Tas\3_Grided_Solar.csv'

# Load CSV files into dataframes
solar_df = pd.read_csv(solar_file)
nearest_points_df = pd.read_csv(nearest_points_file)

# Convert lat and lon columns to string with 6 decimal points
solar_df['lat'] = solar_df['lat'].apply(lambda x: '{:.2f}'.format(x))
solar_df['lon'] = solar_df['lon'].apply(lambda x: '{:.2f}'.format(x))
nearest_points_df['lat'] = nearest_points_df['lat'].apply(lambda x: '{:.2f}'.format(x))
nearest_points_df['lon'] = nearest_points_df['lon'].apply(lambda x: '{:.2f}'.format(x))

# Merge dataframes on 'lat' and 'lon' columns to find matching points
merged_df = pd.merge(solar_df, nearest_points_df, on=['lat', 'lon'], how='inner')

# Select desired columns
output_df = merged_df[['YYYYMMDD', 'lat', 'lon', 'Lat', 'Lon', 'radiation']]

# Write to CSV
output_df.to_csv(output_file, index=False)

print(f"Filtered data written to '{output_file}'.")

